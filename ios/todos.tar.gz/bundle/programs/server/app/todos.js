(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// todos.js                                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Tasks = new Mongo.Collection("tasks");                                 // 1
                                                                       //
if (Meteor.isClient) {                                                 // 3
  Meteor.subscribe("tasks");                                           // 4
                                                                       //
  Template.body.helpers({                                              // 6
    tasks: function () {                                               // 7
      if (Session.get("hideCompleted")) {                              // 8
        return Tasks.find({ checked: { $ne: true } }, { sort: { createdAt: -1 } });
      } else {                                                         //
        return Tasks.find({}, { sort: { createdAt: -1 } });            // 11
      }                                                                //
    },                                                                 //
    incompleteCount: function () {                                     // 14
      return Tasks.find({ checked: { $ne: true } }).count();           // 15
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.body.events({                                               // 20
    "submit .new-task": function (event) {                             // 21
      // Prevent default browser form submit                           //
      event.preventDefault();                                          // 23
                                                                       //
      // Get value from form element                                   //
      var text = event.target.text.value;                              // 26
                                                                       //
      // Insert a task into the collection                             //
      Meteor.call("addTask", text);                                    // 29
                                                                       //
      // Clear form                                                    //
      event.target.text.value = "";                                    // 32
    },                                                                 //
                                                                       //
    "change .hide-completed input": function (event) {                 // 35
      Session.set("hideCompleted", event.target.checked);              // 36
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.task.events({                                               // 40
    "click .toggle-checked": function () {                             // 41
      Meteor.call("setChecked", this._id, !this.checked);              // 42
    },                                                                 //
    "click .delete": function () {                                     // 44
      Meteor.call("deleteTask", this._id);                             // 45
    }                                                                  //
  });                                                                  //
                                                                       //
  Accounts.ui.config({                                                 // 49
    passwordSignupFields: "USERNAME_ONLY"                              // 50
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 54
  Meteor.startup(function () {                                         // 55
    // code to run on server at startup                                //
    Meteor.publish("tasks", function () {                              // 57
      return Tasks.find({ owner: this.userId });                       // 58
    });                                                                //
  });                                                                  //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 63
  addTask: function (text) {                                           // 64
    // Make sure the user is logged in before inserting a task         //
    if (!Meteor.userId()) {                                            // 66
      throw new Meteor.Error("not-authorized");                        // 67
    }                                                                  //
                                                                       //
    Tasks.insert({                                                     // 70
      text: text,                                                      // 71
      createdAt: new Date(),                                           // 72
      owner: Meteor.userId(),                                          // 73
      username: Meteor.user().username                                 // 74
    });                                                                //
  },                                                                   //
                                                                       //
  deleteTask: function (taskId) {                                      // 78
    Tasks.remove(taskId);                                              // 79
  },                                                                   //
                                                                       //
  setChecked: function (taskId, setChecked) {                          // 82
    Tasks.update(taskId, { $set: { checked: setChecked } });           // 83
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=todos.js.map
